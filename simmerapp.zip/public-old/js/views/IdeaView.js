( function ( views ){

	views.IdeaView = Backbone.View.extend({
		tagName : 'li',

		events: {
			'click button': 'voteUp'
		},

		template: _.template($('#resultItemTemplate').html()),

		initialize: function() {
			this.model.on('change:votes', this.test, this);		
		},

		render : function () {
			this.$el.html(this.template(this.model.toJSON()));
			return this;
		},

		voteUp: function(e) {			
			var currentVotes = parseInt(this.model.get('votes'));
			this.model.set('votes', currentVotes + 1);
			this.model.save(null, { 
				success: function(data, response) {
					if(!response.error) {
						
					} else {

					}
				},
				error: function(response) {
				
				}
			});
		},

		test: function() {
			this.$el.find('button').attr('disabled', true);
		}
	});

})( app.views );