(function ( views ) {

	views.AppView = Backbone.View.extend({
		el : '#content',
		

		initialize : function () {			
			var ideas = this.collection; // IdeaCollection.
			ideas.on('reset', this.addAll, this);
			ideas.on('all', this.render, this);
			
			ideas.fetch({
				success: function(collection, response){
					ideas.pager();
				},
				silent:true,				
			});


			vent.on('idea:show', this.showIdea, this);
		},

		addAll : function () {
			this.$el.empty();
			this.collection.each (this.addOne);
		},
		
		addOne : function ( idea ) {
			var view = new views.IdeaView({ model:idea });
			$('#content').append(view.render().el);
		},

		showIdea : function(id) {
			//console.log(window.test.length);
		}

	});

})( app.views );
