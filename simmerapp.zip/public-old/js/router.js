(function(){
	app.router = Backbone.Router.extend({	

		routes: {
			'show/:id': 'show' 
		},
		show: function(id) {
			vent.trigger('idea:show', id);
		}
	});	
})();