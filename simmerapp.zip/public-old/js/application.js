//Top-level namespaces for our code

(function(){

	window.app = {};
	window.vent = _.extend({}, Backbone.Events);
	app.collections = {};
	app.models = {};
	app.views = {};
	app.mixins = {};
	app.router = {};
	

	// Defer initialization until doc ready.
	$(function(){		

		app.collections.ideas = new app.collections.IdeasCollection();
		app.views.app = new app.views.AppView({collection: app.collections.ideas});
		app.views.tools = new app.views.ToolsView({collection: app.collections.ideas});
		app.views.pagination = new app.views.PaginationView({collection: app.collections.ideas});

		new app.router();
		Backbone.history.start();
	});
})();