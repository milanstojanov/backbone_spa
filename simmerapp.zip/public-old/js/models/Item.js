(function ( models ) {
	models.Idea = Backbone.Model.extend({});
})( app.models );