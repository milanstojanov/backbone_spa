(function ( models ) {
	models.Idea = Backbone.Model.extend({
		urlRoot: 'v1/ideas'
	});
})( app.models );