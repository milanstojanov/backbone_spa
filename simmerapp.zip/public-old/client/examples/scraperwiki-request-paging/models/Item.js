(function ( models ) {
	models.Item = Backbone.Model.extend({});
})(app.models);