<!DOCTYPE HTML>
<html lang="en-US">

  <head>

    <meta charset="UTF-8">
    <title>SimmerApp</title>
     <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
     <style>

     </style>
  </head>

  <body>

 <div class="container">
      <div class="page-header">
        <h1>All ideas</h1>
      </div>
      <ul id="tools"></ul>
      <ul id="content"></ul>
      <ul id="pagination"></ul>
    </div>

    <!--sample template for result item-->
    <script type="text/html" id="resultItemTemplate">     
      <h3><%= title %><small> - by <%= user.username %></small></h3>
      <p><%= description %></p>      
      <span class="votes"><%= votes %></span>
      <button class="voteUp btn">+1</button>
    </script>

    <!--sample template for pagination UI-->

    <script type="text/html" id="tmpClientPagination">
     <div class="breadcrumb">

      <span class="cell last pages">
        <% if (currentPage != 1) { %>
          <a href="#" class="first">First</a>
          <a href="#" class="prev">Previous</a>
        <% } %>
        <% _.each (pageSet, function (p) { %>
          <% if (currentPage == p) { %>
            <span class="page selected"><%= p %></span>
          <% } else { %>
            <a href="#" class="page"><%= p %></a>
          <% } %>
        <% }); %>
        <% if (lastPage != currentPage && lastPage != 0) { %>
          <a href="#" class="next">Next</a>
          <a href="#" class="last">Last</a>
        <% } %>
      </span>

      <span class="divider">/</span>

      <span class="cell howmany">
        Show
        <a href="#" class="selected">3</a>
        |
        <a href="#" class="">9</a>
        |
        <a href="#" class="">12</a>
      </span>

      <span class="divider">/</span>
      
      <span class="cell first records">
        <span class="current"><%= startRecord %></span>
        -
        <span class="perpage"><%= endRecord %></span>
        of
        <span class="total"><%= totalRecords %></span>
              shown
      </span>


      <span class="divider">/</span>

      </div>
    </script>

    <script type="text/html" id="tmpTools">
      <div class="breadcrumb">
        <select id="sortByOption">
          <option value="cid">Sort by</option>
          <option value="votes">Rating</option>
          <option value="created_at">Date</option>
        </select>

        <span class="cell sort">
          <a href="#" class="sortAsc btn small">Sort (Asc)</a>
          <a href="#" class="sortDsc btn small">Sort (Desc)</a>
        </span>

        <span class="cell sort">
          <input id="filterString" type="text" class="cell" placeholder="Filter search..."/>
          <a href="#" class="filter btn small">Filter</a>
        </span>
      </div>
    </script>
 
   <!-- Placed at the end of the document so the pages load faster -->
   <script src="{{ asset('js/jquery.js') }}"></script>
   <script src="{{ asset('js/lib/cookie.js') }}"></script>
   <script src="{{ asset('node_modules/underscore/underscore-min.js') }}"></script>
   <script src="{{ asset('node_modules/backbone/backbone-min.js') }}"></script>
   <script src="{{ asset('node_modules/mustache/mustache.js') }}"></script>
   <script src="{{ asset('js/bootstrap.js') }}"></script>

    
    <!-- main app -->    
    <script src="{{ asset('js/application.js') }}"></script>
    <script src="{{ asset('js/router.js') }}"></script>

    <!--Backbone.Paginator-->
    <script src="{{ asset('js/lib/backbone.paginator.js') }}"></script>

    <!--Models/Collections-->
    <script src="{{ asset('js/models/Idea.js') }}"></script>
    <script src="{{ asset('js/collections/IdeasCollection.js') }}"></script>

    <!--Views-->
    <script src="{{ asset('js/views/IdeaView.js') }}"></script>
    <script src="{{ asset('js/views/ToolsView.js') }}"></script>
    <script src="{{ asset('js/views/PaginationView.js') }}"></script>
    <script src="{{ asset('js/views/AppView.js') }}"></script>
    @yield('scripts')
</body>
</html>