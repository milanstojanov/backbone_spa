define(['backbone'], function(Backbone) {
	var Comment = Backbone.Model.extend({		
		
	});

	return Comment;
});
