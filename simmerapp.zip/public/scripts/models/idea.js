define(['backbone', '../collections/ideas'], function(Backbone) {
	var Idea = Backbone.Model.extend({		
		
	});

	return Idea;
});
