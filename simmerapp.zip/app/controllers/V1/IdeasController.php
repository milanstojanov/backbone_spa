<?php
namespace V1;
 
//import classes that are not in this new namespace
use BaseController;
use IdeaRepositoryInterface;
use Input;
use View;
use Carbon\Carbon;
use Cookie; 
use Response;
class IdeasController extends BaseController {

	const NEW_IDEA = 1;
	/**
	* We will use Laravel's dependency injection to auto-magically
	* "inject" our repository instance into our controller
	*/
	public function __construct(IdeaRepositoryInterface $ideas)
	{
		$this->ideas = $ideas;
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
        return $this->ideas->findAll();
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$input = Input::all();

		return $this->ideas->store( array(
			'title' => $input['title'],
			'description' => $input['description'],
			'created_at' => Carbon::now(),
			'votes' => 0,
			'author_id' => 5,
			'status_id' => self::NEW_IDEA
		));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$cookieClient = unserialize(Cookie::get('voted'));
		$votedIdeas = ($cookieClient) ? $cookieClient : array();
		if(in_array($id, $votedIdeas)) {
			return Response::json(array(
		        'error' => true,
		        'message' => 'You have already voted for this'),
		        200
    		); 
		}

		if($this->ideas->update($id, Input::get('votes'))) {
			$votedIdeas[] = $id;
			$cookie = Cookie::make('voted', serialize($votedIdeas));
			return Response::make()->withCookie($cookie);
		}
		
	}

}
