<?php

//use our new namespace
namespace V1;
 
//import classes that are not in this new namespace
use BaseController;
use CommentRepositoryInterface;
use Input;
use View;

class IdeasCommentsController extends BaseController {

	/**
	* We will use Laravel's dependency injection to auto-magically
	* "inject" our repository instance into our controller
	*/
	public function __construct(CommentRepositoryInterface $comments)
	{
		$this->comments = $comments;
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index($idea_id)
	{
        return $this->comments->findAll($idea_id);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store($idea_id)
	{
		return $this->comments->store( $idea_id, Input::all() );
	}

}
