<?php

class Idea extends Eloquent {
	protected $guarded = array();
	public $timestamps = false;

	/**
	* Validation Rules
	* this is just a place for us to store these, you could
	* alternatively place them in your repository
	* @var array
	*/
	public static $rules = array(
		'title'    => 'required',
		'description' => 'required',
		'author_id' => 'required',
	);

	/**
	* Define the relationship with the comments table
	* @return Collection collection of Comment Models
	*/
	public function comments()
	{
		return $this->hasMany('Comment');
	}

	public function user() 
	{
		return $this->belongsTo('User');
	}
}
