<?php

class Comment extends Eloquent {
	protected $guarded = array();

	public static $rules = array();
	public $timestamps = false;

	/**
	* Define the relationship with the posts table
	* @return Model parent Post model
	*/
	public function idea()
	{
		return $this->belongsTo('Idea');
	}
}
