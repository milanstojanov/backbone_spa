<?php

class __Mustache_bb05a1c92cab7902a7f8c71dda5d6b6e extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<dl>
';
        $buffer .= $indent . '  <dt>Q. What did Biggie say when he watched inception?</dt>
';
        $buffer .= $indent . '  <dd>A. "It was all a dream!"</dd>
';
        $buffer .= $indent . '</dl>';

        return $buffer;
    }
}
