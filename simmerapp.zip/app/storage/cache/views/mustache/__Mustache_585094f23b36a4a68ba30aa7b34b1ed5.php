<?php

class __Mustache_585094f23b36a4a68ba30aa7b34b1ed5 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $buffer .= $indent . '<article>
';
        $buffer .= $indent . '  <h3>
';
        $buffer .= $indent . '    ';
        $value = $this->resolveValue($context->findDot('idea.title'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= ' ';
        $value = $this->resolveValue($context->findDot('idea.id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '
';
        $buffer .= $indent . '    <small>';
        $value = $this->resolveValue($context->findDot('idea.author_id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</small>
';
        $buffer .= $indent . '  </h3>
';
        $buffer .= $indent . '  <div>
';
        $buffer .= $indent . '    ';
        $value = $this->resolveValue($context->findDot('idea.description'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '
';
        $buffer .= $indent . '  </div>
';
        $buffer .= $indent . '</article>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '<div>
';
        $buffer .= $indent . '  <h2>Add A Comment</h2>
';
        if ($partial = $this->mustache->loadPartial('comments._form')) {
            $buffer .= $partial->renderInternal($context, '  ');
        }
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '  <section data-role="comments">
';
        // 'idea.comments' section
        $buffer .= $this->sectionFd2451ede4f885c36449e62b4346fa0f($context, $indent, $context->findDot('idea.comments'));
        $buffer .= $indent . '  </section>
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }

    private function sectionFd2451ede4f885c36449e62b4346fa0f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
      <div>
        {{> comments._comment }}
      </div>
    ';
            $buffer .= $this->mustache
                ->loadLambda((string) call_user_func($value, $source, $this->lambdaHelper))
                ->renderInternal($context);
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                $buffer .= $indent . '      <div>
';
                if ($partial = $this->mustache->loadPartial('comments._comment')) {
                    $buffer .= $partial->renderInternal($context, '        ');
                }
                $buffer .= $indent . '      </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
