<?php

class __Mustache_9a70923083d1be939b7b8a4ec63e8d92 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="container">
';
        $buffer .= $indent . '      <div class="page-header">
';
        $buffer .= $indent . '        <h1>All ideas</h1>
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '      <ul id="tools"></ul>
';
        $buffer .= $indent . '      <ul id="content"></ul>
';
        $buffer .= $indent . '      <ul id="pagination"></ul>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <!--sample template for result item-->
';
        $buffer .= $indent . '    <script type="text/html" id="resultItemTemplate">
';
        $buffer .= $indent . '      <h3><%= title %><small> - by <%= user.username %></small></h3>
';
        $buffer .= $indent . '      <p><%= description %></p>
';
        $buffer .= $indent . '      <h4><%= votes %></h4>
';
        $buffer .= $indent . '      <h4><%= created_at %></h4>
';
        $buffer .= $indent . '    </script>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <!--sample template for pagination UI-->
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <script type="text/html" id="tmpClientPagination">
';
        $buffer .= $indent . '     <div class="breadcrumb">
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '      <span class="cell last pages">
';
        $buffer .= $indent . '        <% if (currentPage != 1) { %>
';
        $buffer .= $indent . '          <a href="#" class="first">First</a>
';
        $buffer .= $indent . '          <a href="#" class="prev">Previous</a>
';
        $buffer .= $indent . '        <% } %>
';
        $buffer .= $indent . '        <% _.each (pageSet, function (p) { %>
';
        $buffer .= $indent . '          <% if (currentPage == p) { %>
';
        $buffer .= $indent . '            <span class="page selected"><%= p %></span>
';
        $buffer .= $indent . '          <% } else { %>
';
        $buffer .= $indent . '            <a href="#" class="page"><%= p %></a>
';
        $buffer .= $indent . '          <% } %>
';
        $buffer .= $indent . '        <% }); %>
';
        $buffer .= $indent . '        <% if (lastPage != currentPage && lastPage != 0) { %>
';
        $buffer .= $indent . '          <a href="#" class="next">Next</a>
';
        $buffer .= $indent . '          <a href="#" class="last">Last</a>
';
        $buffer .= $indent . '        <% } %>
';
        $buffer .= $indent . '      </span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '      <span class="divider">/</span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '      <span class="cell howmany">
';
        $buffer .= $indent . '        Show
';
        $buffer .= $indent . '        <a href="#" class="selected">3</a>
';
        $buffer .= $indent . '        |
';
        $buffer .= $indent . '        <a href="#" class="">9</a>
';
        $buffer .= $indent . '        |
';
        $buffer .= $indent . '        <a href="#" class="">12</a>
';
        $buffer .= $indent . '      </span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '      <span class="divider">/</span>
';
        $buffer .= $indent . '      
';
        $buffer .= $indent . '      <span class="cell first records">
';
        $buffer .= $indent . '        <span class="current"><%= startRecord %></span>
';
        $buffer .= $indent . '        -
';
        $buffer .= $indent . '        <span class="perpage"><%= endRecord %></span>
';
        $buffer .= $indent . '        of
';
        $buffer .= $indent . '        <span class="total"><%= totalRecords %></span>
';
        $buffer .= $indent . '              shown
';
        $buffer .= $indent . '      </span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '      <span class="divider">/</span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </script>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <script type="text/html" id="tmpTools">
';
        $buffer .= $indent . '      <div class="breadcrumb">
';
        $buffer .= $indent . '        <select id="sortByOption">
';
        $buffer .= $indent . '          <option value="cid">Sort by</option>
';
        $buffer .= $indent . '          <option value="votes">Rating</option>
';
        $buffer .= $indent . '          <option value="created_at">Date</option>
';
        $buffer .= $indent . '        </select>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '        <span class="cell sort">
';
        $buffer .= $indent . '          <a href="#" class="sortAsc btn small">Sort (Asc)</a>
';
        $buffer .= $indent . '          <a href="#" class="sortDsc btn small">Sort (Desc)</a>
';
        $buffer .= $indent . '        </span>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '        <span class="cell sort">
';
        $buffer .= $indent . '          <input id="filterString" type="text" class="cell" placeholder="Filter search..."/>
';
        $buffer .= $indent . '          <a href="#" class="filter btn small">Filter</a>
';
        $buffer .= $indent . '        </span>
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </script>';

        return $buffer;
    }
}
