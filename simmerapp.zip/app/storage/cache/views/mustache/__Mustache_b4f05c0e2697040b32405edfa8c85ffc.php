<?php

class __Mustache_b4f05c0e2697040b32405edfa8c85ffc extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        if ($partial = $this->mustache->loadPartial('ideas._new')) {
            $buffer .= $partial->renderInternal($context, '');
        }
        // 'ideas' section
        $buffer .= $this->sectionA0fa106c188611d97474502e9160090a($context, $indent, $context->find('ideas'));

        return $buffer;
    }

    private function sectionA0fa106c188611d97474502e9160090a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
  {{> ideas._idea}}
';
            $buffer .= $this->mustache
                ->loadLambda((string) call_user_func($value, $source, $this->lambdaHelper))
                ->renderInternal($context);
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                if ($partial = $this->mustache->loadPartial('ideas._idea')) {
                    $buffer .= $partial->renderInternal($context, '  ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
