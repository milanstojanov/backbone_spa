<?php

class __Mustache_11f2e0537fd310f0cbf66db7cf03bf7a extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<h5>
';
        $buffer .= $indent . '  ';
        $value = $this->resolveValue($context->find('author_id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '
';
        $buffer .= $indent . '  <small>';
        $value = $this->resolveValue($context->find('created_at'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</small>
';
        $buffer .= $indent . '</h5>
';
        $buffer .= $indent . '<div>
';
        $buffer .= $indent . '  ';
        $value = $this->resolveValue($context->find('body'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }
}
