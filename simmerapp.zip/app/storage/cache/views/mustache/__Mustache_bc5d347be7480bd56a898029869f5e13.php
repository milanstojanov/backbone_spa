<?php

class __Mustache_bc5d347be7480bd56a898029869f5e13 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        // 'exists' section
        $buffer .= $this->sectionB06ed95bbe27bd7d3af10ea81bd857bb($context, $indent, $context->find('exists'));
        // 'exists' inverted section
        $value = $context->find('exists');
        if (empty($value)) {
            
            $buffer .= $indent . '  <form action="/v1/ideas" method="POST">
';
        }
        $buffer .= $indent . ' <h3>Nova ideja</h3>
';
        $buffer .= $indent . '  <fieldset>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="control-group">
';
        $buffer .= $indent . '      <label class="control-label">Naslov</label>
';
        $buffer .= $indent . '      <div class="controls">
';
        $buffer .= $indent . '        <input type="text" name="title" value="';
        $value = $this->resolveValue($context->findDot('idea.title'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '" />
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="control-group">
';
        $buffer .= $indent . '      <label class="control-label"></label>
';
        $buffer .= $indent . '      <div class="controls">
';
        $buffer .= $indent . '        <input type="text" name="author_id" value="';
        $value = $this->resolveValue($context->findDot('idea.author_id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '" />
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="control-group">
';
        $buffer .= $indent . '      <label class="control-label"></label>
';
        $buffer .= $indent . '      <div class="controls">
';
        $buffer .= $indent . '        <textarea name="content">';
        $value = $this->resolveValue($context->findDot('idea.description'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</textarea>
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="form-actions">
';
        $buffer .= $indent . '      <input type="submit" class="btn btn-primary" value="Save" />
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '  </fieldset>
';
        $buffer .= $indent . '</form>';

        return $buffer;
    }

    private function sectionB06ed95bbe27bd7d3af10ea81bd857bb(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
  <form action="/v1/ideas/{{ idea.id }}" method="POST">
    <input type="hidden" name="_method" value="PUT" />
';
            $buffer .= $this->mustache
                ->loadLambda((string) call_user_func($value, $source, $this->lambdaHelper))
                ->renderInternal($context);
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                $buffer .= $indent . '  <form action="/v1/ideas/';
                $value = $this->resolveValue($context->findDot('idea.id'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '" method="POST">
';
                $buffer .= $indent . '    <input type="hidden" name="_method" value="PUT" />
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
