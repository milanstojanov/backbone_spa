<?php

class __Mustache_ec2942420299d3a34025dd2d7962e200 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<article data-toggle="view" data-target="ideas/';
        $value = $this->resolveValue($context->find('id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '">
';
        $buffer .= $indent . '  <h3>';
        $value = $this->resolveValue($context->find('title'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= ' ';
        $value = $this->resolveValue($context->find('id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</h3>
';
        $buffer .= $indent . '  <cite>';
        $value = $this->resolveValue($context->find('author_id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= ' on ';
        $value = $this->resolveValue($context->find('created_at'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</cite>
';
        $buffer .= $indent . '</article>';

        return $buffer;
    }
}
