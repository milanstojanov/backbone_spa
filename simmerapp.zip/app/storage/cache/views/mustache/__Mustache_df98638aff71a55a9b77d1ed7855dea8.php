<?php

class __Mustache_df98638aff71a55a9b77d1ed7855dea8 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . 'heheh';

        return $buffer;
    }
}
