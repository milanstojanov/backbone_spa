<?php

class __Mustache_78c83498184805bdc9d69a47d40db594 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';


        return $buffer;
    }
}
