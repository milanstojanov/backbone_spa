<?php

class __Mustache_ab7425ba891372f521ff19f0776f5002 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        // 'ideasssss' section
        $buffer .= $this->sectionA2acb61e3fad0d1c1491441b71656d47($context, $indent, $context->find('ideasssss'));

        return $buffer;
    }

    private function sectionA2acb61e3fad0d1c1491441b71656d47(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
  {{> ideasssss._idea}}
';
            $buffer .= $this->mustache
                ->loadLambda((string) call_user_func($value, $source, $this->lambdaHelper))
                ->renderInternal($context);
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                if ($partial = $this->mustache->loadPartial('ideasssss._idea')) {
                    $buffer .= $partial->renderInternal($context, '  ');
                }
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
