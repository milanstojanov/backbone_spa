<?php

class __Mustache_45d0cd1f53b41dec97272ab0c5d610bd extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        // 'exists' section
        $buffer .= $this->section6b913823fa6ffc18fb39c0d959e88e45($context, $indent, $context->find('exists'));
        // 'exists' inverted section
        $value = $context->find('exists');
        if (empty($value)) {
            
            $buffer .= $indent . '  <form class="form-horizontal" action="/v1/ideas/';
            $value = $this->resolveValue($context->findDot('comment.idea_id'), $context, $indent);
            $buffer .= htmlspecialchars($value, 2, 'UTF-8');
            $buffer .= '" method="post">
';
        }
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '  <fieldset>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="control-group">
';
        $buffer .= $indent . '      <label class="control-label">Author Name</label>
';
        $buffer .= $indent . '      <div class="controls">
';
        $buffer .= $indent . '        <input type="text" name="author_id" value="';
        $value = $this->resolveValue($context->findDot('comment.author_id'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '" />
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="control-group">
';
        $buffer .= $indent . '      <label class="control-label">Comment</label>
';
        $buffer .= $indent . '      <div class="controls">
';
        $buffer .= $indent . '        <textarea name="content">';
        $value = $this->resolveValue($context->findDot('comment.body'), $context, $indent);
        $buffer .= htmlspecialchars($value, 2, 'UTF-8');
        $buffer .= '</textarea>
';
        $buffer .= $indent . '      </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '    <div class="form-actions">
';
        $buffer .= $indent . '      <input type="submit" class="btn btn-primary" value="Save" />
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . ' 
';
        $buffer .= $indent . '  </fieldset>
';
        $buffer .= $indent . '</form>';

        return $buffer;
    }

    private function section6b913823fa6ffc18fb39c0d959e88e45(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <form class="form-horizontal" action="/v1/ideas/{{ comment.idea_id }}/{{ id }}" method="post">
    <input type="hidden" name="_method" value="PUT" />
';
            $buffer .= $this->mustache
                ->loadLambda((string) call_user_func($value, $source, $this->lambdaHelper))
                ->renderInternal($context);
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                $buffer .= $indent . '    <form class="form-horizontal" action="/v1/ideas/';
                $value = $this->resolveValue($context->findDot('comment.idea_id'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '/';
                $value = $this->resolveValue($context->find('id'), $context, $indent);
                $buffer .= htmlspecialchars($value, 2, 'UTF-8');
                $buffer .= '" method="post">
';
                $buffer .= $indent . '    <input type="hidden" name="_method" value="PUT" />
';
                $context->pop();
            }
        }
    
        return $buffer;
    }
}
